﻿Public Class frmmenu
    Public totaltab As Integer = 0
    Public x As Integer
    Private Function getTabIndex(ByVal sCari As String)
        Dim i As Integer
        For i = 0 To totaltab - 1
            If (TabControl1.Tabs(i).Text = sCari) Then
                Exit For
            End If
        Next
        getTabIndex = i
    End Function
    Private Sub BikinMenu(ByVal Child As Form, ByVal sTitle As String)
        Dim newTab As DevComponents.DotNetBar.TabItem = TabControl1.CreateTab(sTitle)
        Dim panel As DevComponents.DotNetBar.TabControlPanel = DirectCast(newTab.AttachedControl, Panel)


        Child.TopLevel = False
        Child.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Child.Dock = DockStyle.Fill
        Child.Show()
        panel.Controls.Add(Child)
    End Sub
    Private Sub TabControl1_ControlAdded(sender As Object, e As ControlEventArgs) Handles TabControl1.ControlAdded
        TabControl1.SelectedTabIndex = totaltab - 1
    End Sub

    Private Sub TabControl1_TabItemClose(sender As Object, e As DevComponents.DotNetBar.TabStripActionEventArgs) Handles TabControl1.TabItemClose
        Dim itemToRemove As DevComponents.DotNetBar.TabItem = TabControl1.SelectedTab
        If (totaltab > 2) Then
            totaltab = totaltab - 1
        Else
            totaltab = 0
        End If
        TabControl1.Tabs.Remove(itemToRemove)
        TabControl1.Controls.Remove(itemToRemove.AttachedControl)
        TabControl1.RecalcLayout()

        If (itemToRemove.ToString = "pendataan") Then
            menu_pembagian = False
        End If

    End Sub
    Private Sub TabControl1_TabItemOpen(sender As Object, e As EventArgs) Handles TabControl1.TabItemOpen
        If (totaltab = 0) Then
            totaltab = totaltab + 2
        Else
            totaltab = totaltab + 1
        End If
    End Sub
    Private Sub ButtonItem14_Click(sender As Object, e As EventArgs) Handles ButtonItem14.Click
        If (menu_pendataan = False) Then
            Bikinmenu(cldpendataan, "pendataan")
            menu_pendataan = True
        Else
            x = getTabIndex("pendataan")
            TabControl1.SelectedTabIndex = x
        End If
    End Sub

    Private Sub ButtonItem15_Click(sender As Object, e As EventArgs) Handles ButtonItem15.Click
        If (menu_pembagian = False) Then
            BikinMenu(cldpembagian, "pembagian")
            menu_pembagian = True
        Else
            x = getTabIndex("pembagian")
            TabControl1.SelectedTabIndex = x
        End If
    End Sub

    Private Sub TabControl1_Click(sender As Object, e As EventArgs) Handles TabControl1.Click

    End Sub
End Class
