﻿Public Class pembagian
    Dim strsql As String
    Dim info As String
    Private _ino As Integer
    Private _idpembagian As String
    Private _blok1 As String
    Private _penerima As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property ino()
        Get
            Return _ino
        End Get
        Set(ByVal value)
            _ino = value
        End Set
    End Property
    Public Property idpembagian()
        Get
            Return _idpembagian
        End Get
        Set(ByVal value)
            _idpembagian = value
        End Set
    End Property
    Public Property blok1()
        Get
            Return _blok1
        End Get
        Set(ByVal value)
            _blok1 = value
        End Set
    End Property
    Public Property penerima()
        Get
            Return _penerima
        End Get
        Set(ByVal value)
            _penerima = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (pembagian_baru = True) Then
            strsql = "Insert into pembagian(idpembagian,blok,penerima) values ('" & idpembagian & "','" & blok1 & "','" & penerima & "')"
            info = "INSERT"
        Else
            strsql = "update pembagian set idpembagian='" & idpembagian & "', blok='" & blok1 & "', penerima='" & penerima & "' where idpembagian='" & idpembagian & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Caripembagian(ByVal sidpembagian As String)
        DBConnect()
        strsql = "SELECT * FROM pembagian WHERE idpembagian='" & sidpembagian & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            pembagian_baru = False
            DR.Read()
            idpembagian = Convert.ToString((DR("idpembagian")))
            blok1 = Convert.ToString((DR("blok")))
            penerima = Convert.ToString((DR("penerima")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            pembagian_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sidpembagian As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM pembagian WHERE idpembagian='" & sidpembagian & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM pembagian"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class
