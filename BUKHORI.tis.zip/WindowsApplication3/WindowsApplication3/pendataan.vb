﻿Public Class pendataan
    Dim strsql As String
    Dim info As String
    Private _no As Integer
    Private _idpendataan As String
    Private _nama As String
    Private _blok As String
    Private _jenis_hewan As String
    Private _jumlah_hewan As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property no()
        Get
            Return _no
        End Get
        Set(ByVal value)
            _no = value
        End Set
    End Property
    Public Property idpendataan()
        Get
            Return _idpendataan
        End Get
        Set(ByVal value)
            _idpendataan = value
        End Set
    End Property
    Public Property nama()
        Get
            Return _nama
        End Get
        Set(ByVal value)
            _nama = value
        End Set
    End Property
    Public Property blok()
        Get
            Return _blok
        End Get
        Set(ByVal value)
            _blok = value
        End Set
    End Property
    Public Property jenis_hewan()
        Get
            Return _jenis_hewan
        End Get
        Set(ByVal value)
            _jenis_hewan = value
        End Set
    End Property
    Public Property jumlah()
        Get
            Return _jumlah_hewan
        End Get
        Set(ByVal value)
            _jumlah_hewan = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (pendataan_baru = True) Then
            strsql = "Insert into pendataan(idpendataan,nama,blok,jenis_hewan,jumlah_hewan) values ('" & idpendataan & "','" & nama & "','" & blok & "','" & jenis_hewan & "','" & jumlah & "')"
            info = "INSERT"
        Else
            strsql = "update pendataan set idpendataan='" & idpendataan & "', nama='" & nama & "', blok='" & blok & "', jenis_hewan='" & jenis_hewan & "', jumlah_hewan='" & jumlah & "' where idpendataan='" & idpendataan & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Caripendataan(ByVal sidpendataan As String)
        DBConnect()
        strsql = "SELECT * FROM pendataan WHERE idpendataan='" & sidpendataan & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            pendataan_baru = False
            DR.Read()
            idpendataan = Convert.ToString((DR("idpendataan")))
            nama = Convert.ToString((DR("nama")))
            blok = Convert.ToString((DR("blok")))
            jenis_hewan = Convert.ToString((DR("jenis_hewan")))
            _jumlah_hewan = Convert.ToString((DR("jumlah_hewan")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            pendataan_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sidpendataan As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM pendataan WHERE idpendataan='" & sidpendataan & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM pendataan"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class
