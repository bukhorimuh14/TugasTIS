﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpembagian
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnhapus = New System.Windows.Forms.Button()
        Me.btnreset = New System.Windows.Forms.Button()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.btncari = New System.Windows.Forms.Button()
        Me.txtblok1 = New System.Windows.Forms.ComboBox()
        Me.txtpenerima = New System.Windows.Forms.TextBox()
        Me.txtpembagian = New System.Windows.Forms.TextBox()
        Me.txtino = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.pendataan = New System.Windows.Forms.Label()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnhapus
        '
        Me.btnhapus.Location = New System.Drawing.Point(458, 180)
        Me.btnhapus.Name = "btnhapus"
        Me.btnhapus.Size = New System.Drawing.Size(75, 23)
        Me.btnhapus.TabIndex = 23
        Me.btnhapus.Text = "HAPUS"
        Me.btnhapus.UseVisualStyleBackColor = True
        '
        'btnreset
        '
        Me.btnreset.Location = New System.Drawing.Point(458, 145)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(75, 23)
        Me.btnreset.TabIndex = 22
        Me.btnreset.Text = "RESET"
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btnsimpan
        '
        Me.btnsimpan.Location = New System.Drawing.Point(458, 108)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(75, 23)
        Me.btnsimpan.TabIndex = 21
        Me.btnsimpan.Text = "SIMPAN"
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'btncari
        '
        Me.btncari.Location = New System.Drawing.Point(458, 70)
        Me.btncari.Name = "btncari"
        Me.btncari.Size = New System.Drawing.Size(75, 23)
        Me.btncari.TabIndex = 20
        Me.btncari.Text = "CARI"
        Me.btncari.UseVisualStyleBackColor = True
        '
        'txtblok1
        '
        Me.txtblok1.FormattingEnabled = True
        Me.txtblok1.Items.AddRange(New Object() {"manis", "wage", "pon", "kliwon", "pahing"})
        Me.txtblok1.Location = New System.Drawing.Point(190, 145)
        Me.txtblok1.Name = "txtblok1"
        Me.txtblok1.Size = New System.Drawing.Size(134, 21)
        Me.txtblok1.TabIndex = 19
        '
        'txtpenerima
        '
        Me.txtpenerima.Location = New System.Drawing.Point(190, 180)
        Me.txtpenerima.Name = "txtpenerima"
        Me.txtpenerima.Size = New System.Drawing.Size(134, 20)
        Me.txtpenerima.TabIndex = 18
        '
        'txtpembagian
        '
        Me.txtpembagian.Location = New System.Drawing.Point(190, 113)
        Me.txtpembagian.Name = "txtpembagian"
        Me.txtpembagian.Size = New System.Drawing.Size(134, 20)
        Me.txtpembagian.TabIndex = 17
        '
        'txtino
        '
        Me.txtino.Location = New System.Drawing.Point(190, 73)
        Me.txtino.Name = "txtino"
        Me.txtino.Size = New System.Drawing.Size(134, 20)
        Me.txtino.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(76, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Penerima"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(76, 145)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Blok"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(76, 113)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "ID Pembagian"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(76, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "No"
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(36, 231)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(631, 218)
        Me.DataGridView2.TabIndex = 24
        '
        'pendataan
        '
        Me.pendataan.AutoSize = True
        Me.pendataan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pendataan.Location = New System.Drawing.Point(271, 9)
        Me.pendataan.Name = "pendataan"
        Me.pendataan.Size = New System.Drawing.Size(185, 13)
        Me.pendataan.TabIndex = 25
        Me.pendataan.Text = "PEMBAGIAN HEWAN QURBAN"
        '
        'frmpembagian
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(702, 446)
        Me.Controls.Add(Me.pendataan)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.btnhapus)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.btncari)
        Me.Controls.Add(Me.txtblok1)
        Me.Controls.Add(Me.txtpenerima)
        Me.Controls.Add(Me.txtpembagian)
        Me.Controls.Add(Me.txtino)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmpembagian"
        Me.Text = "frmpembagian"
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhapus As System.Windows.Forms.Button
    Friend WithEvents btnreset As System.Windows.Forms.Button
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents btncari As System.Windows.Forms.Button
    Friend WithEvents txtblok1 As System.Windows.Forms.ComboBox
    Friend WithEvents txtpenerima As System.Windows.Forms.TextBox
    Friend WithEvents txtpembagian As System.Windows.Forms.TextBox
    Friend WithEvents txtino As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents pendataan As System.Windows.Forms.Label
End Class
