﻿Public Class frmpendataan

    Private Sub frmpendataan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Reload()
        opendataan.Caripendataan(txtidpendataan.Text)
        If (pembagian_baru = False) Then

        Else
            MessageBox.Show("Data TerLoad")
        End If
    End Sub

    Private Sub Reload()
        oPendataan.getAllData(DataGridView1)
    End Sub

    Private Sub TampilPendataan()
        txtno.Text = opendataan.no
        txtidpendataan.Text = opendataan.idpendataan
        txtnama.Text = opendataan.nama
        txtblok.Text = opendataan.blok
        txtjenishewan.Text = opendataan.jenis_hewan
        txtjumlah.Text = opendataan.jumlah

    End Sub

    Private Sub SimpanDatapendataan()
        opendataan.idpendataan = txtidpendataan.text
        opendataan.nama = txtnama.text
        opendataan.blok = txtblok.text
        oPendataan.jenis_hewan = txtjenishewan.Text
        oPendataan.jumlah = txtjumlah.Text
        opendataan.Simpan()
        Reload()
        If (opendataan.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (opendataan.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub

    Private Sub ClearEntry()
        txtidpendataan.Clear()
        txtnama.Clear()
        txtblok.SelectedIndex = -1
        txtjenishewan.SelectedIndex = -1
        txtjumlah.Clear()
        txtidpendataan.Focus()
    End Sub

    Private Sub Hapus()
        If (pendataan_baru = False And txtidpendataan.Text <> "") Then
            opendataan.Hapus(txtidpendataan.Text)
            ClearEntry()
            Reload()
        End If
    End Sub

    Private Sub txtidpendataan_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtidpendataan.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            opendataan.Caripendataan(txtidpendataan.Text)
            If (pendataan_baru = False) Then
                Tampilpendataan()
            Else
                MessageBox.Show("Data tidak ditemukan")
            End If
        End If
    End Sub

   

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhapus.Click
        Dim jawab As Integer
        jawab = MessageBox.Show("Apakah Data akan dihapus", "Confirm", MessageBoxButtons.YesNo)
        If (jawab = vbYes) Then
            Hapus()
        Else
            MessageBox.Show("Data batal dihapus")
        End If
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        ClearEntry()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        If (txtidpendataan.Text <> "" And txtnama.Text <> "") Then
            SimpanDatapendataan()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("idpendataan dan nama tidak boleh kosong!")
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub btncari_Click(sender As Object, e As EventArgs) Handles btncari.Click
        opendataan.Caripendataan(txtidpendataan.Text)
        If (pendataan_baru = False) Then
            TampilPendataan()
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmreport.Show()
        Me.Hide()
    End Sub

    Private Sub txtblok_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtblok.SelectedIndexChanged

    End Sub
End Class