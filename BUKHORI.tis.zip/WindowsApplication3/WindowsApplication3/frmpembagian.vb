﻿Public Class frmpembagian

    Private Sub frmpembagian_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
        opembagian.Caripembagian(txtpembagian.Text)
        If (pembagian_baru = False) Then

        Else
            MessageBox.Show("Data TerLoad")
        End If
    End Sub

    Private Sub Reload()
        opembagian.getAllData(DataGridView2)
    End Sub

    Private Sub Tampilpembagian()
        txtino.Text = opembagian.ino
        txtpembagian.Text = opembagian.idpembagian
        txtblok1.Text = opembagian.blok1
        txtpenerima.Text = opembagian.penerima
    End Sub

    Private Sub SimpanDatapembagian()
        opembagian.ino = txtino.Text
        oPembagian.idpembagian = txtpembagian.Text
        opembagian.blok1 = txtblok1.Text
        opembagian.penerima = txtpenerima.text
        opembagian.Simpan()
        Reload()
        If (opembagian.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (opembagian.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub

    Private Sub ClearEntry()
        txtino.Clear()
        txtpembagian.Clear()
        txtblok1.SelectedIndex = -1
        txtpenerima.Clear()

    End Sub

    Private Sub Hapus()
        If (pembagian_baru = False And txtpenerima.Text <> "") Then
            oPembagian.Hapus(txtpenerima.Text)
            ClearEntry()
            Reload()
        End If
    End Sub

    Private Sub txtino_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtino.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            oPembagian.Caripembagian(txtpenerima.Text)
            If (pembagian_baru = False) Then
                TampilPembagian()
            Else
                MessageBox.Show("Data tidak ditemukan")
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btncari.Click
        opembagian.Caripembagian(txtpembagian.Text)
        If (pendataan_baru = False) Then
            TampilPembagian()
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        Dim jawab As Integer
        jawab = MessageBox.Show("Apakah Data akan dihapus", "Confirm", MessageBoxButtons.YesNo)
        If (jawab = vbYes) Then
            Hapus()
        Else
            MessageBox.Show("Data batal dihapus")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        ClearEntry()
    End Sub

    Private Sub btnsimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        If (txtpenerima.Text <> "") Then
            SimpanDatapembagian()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("nota dan tanggal tidak boleh kosong!")
        End If
    End Sub

    Private Sub txtblok1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtblok1.SelectedIndexChanged

    End Sub
End Class