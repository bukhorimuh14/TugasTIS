﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpendataan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtidpendataan = New System.Windows.Forms.TextBox()
        Me.txtjenishewan = New System.Windows.Forms.ComboBox()
        Me.txtblok = New System.Windows.Forms.ComboBox()
        Me.txtjumlah = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.txtno = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.idpembagian = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnsimpan = New System.Windows.Forms.Button()
        Me.btnhapus = New System.Windows.Forms.Button()
        Me.btnreset = New System.Windows.Forms.Button()
        Me.btncari = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.pendataan = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtidpendataan
        '
        Me.txtidpendataan.Location = New System.Drawing.Point(152, 106)
        Me.txtidpendataan.Name = "txtidpendataan"
        Me.txtidpendataan.Size = New System.Drawing.Size(129, 20)
        Me.txtidpendataan.TabIndex = 36
        '
        'txtjenishewan
        '
        Me.txtjenishewan.FormattingEnabled = True
        Me.txtjenishewan.Items.AddRange(New Object() {"sapi", "kambing", "kerbau"})
        Me.txtjenishewan.Location = New System.Drawing.Point(412, 102)
        Me.txtjenishewan.Name = "txtjenishewan"
        Me.txtjenishewan.Size = New System.Drawing.Size(127, 21)
        Me.txtjenishewan.TabIndex = 34
        '
        'txtblok
        '
        Me.txtblok.FormattingEnabled = True
        Me.txtblok.Items.AddRange(New Object() {"manis", "wage", "kliwon", "pahing", "pon"})
        Me.txtblok.Location = New System.Drawing.Point(412, 65)
        Me.txtblok.Name = "txtblok"
        Me.txtblok.Size = New System.Drawing.Size(127, 21)
        Me.txtblok.TabIndex = 33
        '
        'txtjumlah
        '
        Me.txtjumlah.Location = New System.Drawing.Point(410, 140)
        Me.txtjumlah.Name = "txtjumlah"
        Me.txtjumlah.Size = New System.Drawing.Size(129, 20)
        Me.txtjumlah.TabIndex = 29
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(152, 140)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(129, 20)
        Me.txtnama.TabIndex = 28
        '
        'txtno
        '
        Me.txtno.Location = New System.Drawing.Point(152, 68)
        Me.txtno.Name = "txtno"
        Me.txtno.Size = New System.Drawing.Size(129, 20)
        Me.txtno.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(325, 106)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 13)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Jenis Hewan"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(325, 147)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Jumlah"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(325, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Blok"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(59, 147)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Nama"
        '
        'idpembagian
        '
        Me.idpembagian.AutoSize = True
        Me.idpembagian.Location = New System.Drawing.Point(59, 106)
        Me.idpembagian.Name = "idpembagian"
        Me.idpembagian.Size = New System.Drawing.Size(66, 13)
        Me.idpembagian.TabIndex = 22
        Me.idpembagian.Text = "idpendataan"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(59, 75)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(21, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "No"
        '
        'btnsimpan
        '
        Me.btnsimpan.Location = New System.Drawing.Point(68, 232)
        Me.btnsimpan.Name = "btnsimpan"
        Me.btnsimpan.Size = New System.Drawing.Size(75, 23)
        Me.btnsimpan.TabIndex = 37
        Me.btnsimpan.Text = "SIMPAN"
        Me.btnsimpan.UseVisualStyleBackColor = True
        '
        'btnhapus
        '
        Me.btnhapus.Location = New System.Drawing.Point(207, 232)
        Me.btnhapus.Name = "btnhapus"
        Me.btnhapus.Size = New System.Drawing.Size(75, 23)
        Me.btnhapus.TabIndex = 38
        Me.btnhapus.Text = "HAPUS"
        Me.btnhapus.UseVisualStyleBackColor = True
        '
        'btnreset
        '
        Me.btnreset.Location = New System.Drawing.Point(344, 232)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(75, 23)
        Me.btnreset.TabIndex = 39
        Me.btnreset.Text = "RESET"
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btncari
        '
        Me.btncari.Location = New System.Drawing.Point(464, 232)
        Me.btncari.Name = "btncari"
        Me.btncari.Size = New System.Drawing.Size(75, 23)
        Me.btncari.TabIndex = 40
        Me.btncari.Text = "CARI"
        Me.btncari.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(35, 318)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(681, 150)
        Me.DataGridView1.TabIndex = 41
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(412, 167)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(46, 13)
        Me.LinkLabel1.TabIndex = 42
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Laporan"
        '
        'pendataan
        '
        Me.pendataan.AutoSize = True
        Me.pendataan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pendataan.Location = New System.Drawing.Point(270, 23)
        Me.pendataan.Name = "pendataan"
        Me.pendataan.Size = New System.Drawing.Size(188, 13)
        Me.pendataan.TabIndex = 43
        Me.pendataan.Text = "PENDATAAN HEWAN QURBAN"
        '
        'frmpendataan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(755, 439)
        Me.Controls.Add(Me.pendataan)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btncari)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnhapus)
        Me.Controls.Add(Me.btnsimpan)
        Me.Controls.Add(Me.txtidpendataan)
        Me.Controls.Add(Me.txtjenishewan)
        Me.Controls.Add(Me.txtblok)
        Me.Controls.Add(Me.txtjumlah)
        Me.Controls.Add(Me.txtnama)
        Me.Controls.Add(Me.txtno)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.idpembagian)
        Me.Controls.Add(Me.Label9)
        Me.Name = "frmpendataan"
        Me.Text = "frmpendataan"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtidpendataan As System.Windows.Forms.TextBox
    Friend WithEvents txtjenishewan As System.Windows.Forms.ComboBox
    Friend WithEvents txtblok As System.Windows.Forms.ComboBox
    Friend WithEvents txtjumlah As System.Windows.Forms.TextBox
    Friend WithEvents txtnama As System.Windows.Forms.TextBox
    Friend WithEvents txtno As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents idpembagian As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnsimpan As System.Windows.Forms.Button
    Friend WithEvents btnhapus As System.Windows.Forms.Button
    Friend WithEvents btnreset As System.Windows.Forms.Button
    Friend WithEvents btncari As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents pendataan As System.Windows.Forms.Label
End Class
