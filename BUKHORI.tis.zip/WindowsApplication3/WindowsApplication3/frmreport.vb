﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms
Public Class frmreport
    Dim rpt As New Report
    Dim ds As New DataSet1
    Private Sub Rpelanggan_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        rpt.HostName = "localhost"
        rpt.DatabaseName = "qurban"
        rpt.DatabaseUsername = "root"
        rpt.DatabasePassword = ""

        rpt.DataSetName = "DataSet1"
        rpt.DataTableName = "pendataan"
        rpt.ReportFilename = "Report1.rdlc"
        rpt.SqlQuery = "select * from pendataan"

        rpt.LoadReport(ReportViewer1, ds)
        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub frmreport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ReportViewer1.RefreshReport()
    End Sub
    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load

    End Sub
End Class